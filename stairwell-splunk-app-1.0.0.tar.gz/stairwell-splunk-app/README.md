# Stairwell App for Splunk

Add Stairwell enrichment data to your Splunk events with the Stairwell App for Splunk. This application uses Stairwell private malware analysis to integrate directly with your Splunk experience. Enrich Splunk events based on analyis of hostnames, IP Address and file hashes.

The Stairwell App for Splunk requires a valid Stairwell API license and Splunk user privileges required for app installation. The app makes calls to the Stairwell API. When the app is installed you have access to Stairwell commands to provide data enrichment that extends your defences beyond the limitations of traditional SIEMS tools.

The Stairwell App for Splunk is compatible with Splunk Enterprise 9.4.0

For the very latest information on how to use this app visit [Stairwell App for Splunk](https://docs.stairwell.com/docs/configure-splunk-application)

## Details
### Streaming command
This command operates on each event independently resulting from a search. It adds Stairwell enrichment data to each event that matches the type of data and the criteria given.

There are 3 types of data currently supported:

#### Hostnames
Example: find any field in the event called "host" and add Stairwell hostname enrichment data to it.

```
| makeresults | eval host = "google.com" | stairwell hostname="host"
```

#### IP Addresses
Example: find any field in the event called "ipaddress" and add Stairwell IP Address enrichment data to it.

```
| makeresults | eval ip = "192.168.0.1" | stairwell ip="ip"
```

#### Objects (file hashes)
File hashes currently supported include MD5, SHA1, SHA256.
Example: find any field in the event called "SHA256" and add Stairwell object enrichment data to it.

```
| makeresults | eval hash = "0385eeab00e946a302b24a91dea4187c1210597b8e17cd9e2230450f5ece21da" | stairwell object="hash"
```

### What Stairwell enrichment data is provided?
See [Stairwell App for Splunk](https://docs.stairwell.com/docs/configure-splunk-application) for details.

## Installation
### Prerequisites
1. To use the Stairwell analysis capability you will require an Authentication Token and an Organization Id.
1.1 If you have an existing Stairwell account, please go to https://app.stairwell.com/settings.  If not, please contact sales@stairwell.com
2. To install the Stairwell App for Splunk you require Splunk privileges that allow app installation and configuration. To use the Stairwell App for Splunk you require priv1, priv2???

### Installing
1. Download the app .tar.gz from [GitHub](https://github.com/stairwell-inc/integrations).
2. Log into your Splunk web interface.
3. Navigate to Apps > Manage Apps.
4. Click install app from file.
5. Use the file explorer to find the file you downloaded.
6. Click on upload. 
7. Once the upload is successful, you can configure the app. However, it is recommended that you select "Set up later"
9. Perform a Splunk restart. ```$SPLUNK_HOME/bin/splunk restart```
10. Log into your Splunk web interface again.
11. Navigate to Apps > Stairwell App for Splunk.
12. Click the box that says "Continue to app setup page"
13. Enter your Authentication Token and Organization ID, then click Submit.
14. Stairwell for Splunk App home page will now appear.

## Troubleshooting
Please contact __support@stairwell.com__ for help.

## Contact
Please contact __support@stairwell.com__.

## Version History
|Version|Release Date|Compatibility|Compliance|Actions|
|-------|------------|-------------|----------|-------|
|1.0.0|TBD|Splunk Enterprise|N/A|Download link|


curl -X POST \
    -H "Authorization: bearer eyJraWQiOiJlcmFZc0tkclp4RVhDeVJCaXpBbzliVEtsSW9aWTRySXJsTHFMeHdsTXdFIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULllVZFhIUnpDRWgtZ3JNU3lBemdIRHlubnh0Ykx6RzduUVFaNFd6R2hqTWciLCJpc3MiOiJodHRwczovL2lkcC5sb2dpbi5zcGx1bmsuY29tL29hdXRoMi9hdXNnemp3c2V0Y2hQVklsZzJwNyIsImF1ZCI6ImFwaS5zcGx1bmsuY29tIiwiaWF0IjoxNzQyMjI5OTI3LCJleHAiOjE3NDIyNTg3MjcsImNpZCI6IjBvYWd6anZwcXRzZHRZUDM1MnA3IiwidWlkIjoiMDB1MTM2YXI0dnR1TmxER2sycDgiLCJzY3AiOlsib3BlbmlkIl0sImF1dGhfdGltZSI6MTc0MjIyOTkyNywic3ViIjoibHVjaWVuLmVja2VydEBzdGFpcndlbGwuY29tIiwidW5hbWUiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20iLCJuYW1lIjoiTHVjaWVuIEVja2VydCIsInVzZXIiOnsiZW1haWwiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20ifSwiZW1haWwiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20ifQ.OIuxrzsGyn0MVMUcK54JcSQocUhtfwHEFqQ-_Gu5hB6z6Ql-q4OEJgPEo4iS0T7rzfZhXIn3CFhgoDJlqqZuniqOQOktIRXRrMb3QUXPK5xlcyRg1ibP5ZIiRBI8C3zU5_VI599Zk1PhvJF3y-YGDbzWqyH0MeBuikvLKSyYXgFTvhO_KoW4uLp_PP9RWUeURdC0NDXkeI698nv82BxfmLvVn3kDoTeYrS3K8vdWSeubvyLJykabf5VILcIN5fuLa0rY3hkBBgfiZV6xmBNRr3CFnVm5c_CnuofMFy94A6AQZFQ42IlcYCcwoj1GIkfi3si3L9PvVndFz0fgTq4h-A" \
    -H "Cache-Control: no-cache" \
    -F "app_package=@/home/lucien.eckert/integrations/stairwell-splunk-app-1.0.0.tar.gz" \
    -F "included_tags=cloud" \
    --url "https://appinspect.splunk.com/v1/app/validate"

curl -X GET \
    -H "Authorization: bearer eyJraWQiOiJlcmFZc0tkclp4RVhDeVJCaXpBbzliVEtsSW9aWTRySXJsTHFMeHdsTXdFIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULllVZFhIUnpDRWgtZ3JNU3lBemdIRHlubnh0Ykx6RzduUVFaNFd6R2hqTWciLCJpc3MiOiJodHRwczovL2lkcC5sb2dpbi5zcGx1bmsuY29tL29hdXRoMi9hdXNnemp3c2V0Y2hQVklsZzJwNyIsImF1ZCI6ImFwaS5zcGx1bmsuY29tIiwiaWF0IjoxNzQyMjI5OTI3LCJleHAiOjE3NDIyNTg3MjcsImNpZCI6IjBvYWd6anZwcXRzZHRZUDM1MnA3IiwidWlkIjoiMDB1MTM2YXI0dnR1TmxER2sycDgiLCJzY3AiOlsib3BlbmlkIl0sImF1dGhfdGltZSI6MTc0MjIyOTkyNywic3ViIjoibHVjaWVuLmVja2VydEBzdGFpcndlbGwuY29tIiwidW5hbWUiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20iLCJuYW1lIjoiTHVjaWVuIEVja2VydCIsInVzZXIiOnsiZW1haWwiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20ifSwiZW1haWwiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20ifQ.OIuxrzsGyn0MVMUcK54JcSQocUhtfwHEFqQ-_Gu5hB6z6Ql-q4OEJgPEo4iS0T7rzfZhXIn3CFhgoDJlqqZuniqOQOktIRXRrMb3QUXPK5xlcyRg1ibP5ZIiRBI8C3zU5_VI599Zk1PhvJF3y-YGDbzWqyH0MeBuikvLKSyYXgFTvhO_KoW4uLp_PP9RWUeURdC0NDXkeI698nv82BxfmLvVn3kDoTeYrS3K8vdWSeubvyLJykabf5VILcIN5fuLa0rY3hkBBgfiZV6xmBNRr3CFnVm5c_CnuofMFy94A6AQZFQ42IlcYCcwoj1GIkfi3si3L9PvVndFz0fgTq4h-A" \
    --url "https://appinspect.splunk.com//v1/app/validate/status/2cae2712-f5e5-495d-9f6b-739c8505ef65"

curl -X GET \
    -H "Authorization: bearer eyJraWQiOiJlcmFZc0tkclp4RVhDeVJCaXpBbzliVEtsSW9aWTRySXJsTHFMeHdsTXdFIiwiYWxnIjoiUlMyNTYifQ.eyJ2ZXIiOjEsImp0aSI6IkFULllVZFhIUnpDRWgtZ3JNU3lBemdIRHlubnh0Ykx6RzduUVFaNFd6R2hqTWciLCJpc3MiOiJodHRwczovL2lkcC5sb2dpbi5zcGx1bmsuY29tL29hdXRoMi9hdXNnemp3c2V0Y2hQVklsZzJwNyIsImF1ZCI6ImFwaS5zcGx1bmsuY29tIiwiaWF0IjoxNzQyMjI5OTI3LCJleHAiOjE3NDIyNTg3MjcsImNpZCI6IjBvYWd6anZwcXRzZHRZUDM1MnA3IiwidWlkIjoiMDB1MTM2YXI0dnR1TmxER2sycDgiLCJzY3AiOlsib3BlbmlkIl0sImF1dGhfdGltZSI6MTc0MjIyOTkyNywic3ViIjoibHVjaWVuLmVja2VydEBzdGFpcndlbGwuY29tIiwidW5hbWUiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20iLCJuYW1lIjoiTHVjaWVuIEVja2VydCIsInVzZXIiOnsiZW1haWwiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20ifSwiZW1haWwiOiJsdWNpZW4uZWNrZXJ0QHN0YWlyd2VsbC5jb20ifQ.OIuxrzsGyn0MVMUcK54JcSQocUhtfwHEFqQ-_Gu5hB6z6Ql-q4OEJgPEo4iS0T7rzfZhXIn3CFhgoDJlqqZuniqOQOktIRXRrMb3QUXPK5xlcyRg1ibP5ZIiRBI8C3zU5_VI599Zk1PhvJF3y-YGDbzWqyH0MeBuikvLKSyYXgFTvhO_KoW4uLp_PP9RWUeURdC0NDXkeI698nv82BxfmLvVn3kDoTeYrS3K8vdWSeubvyLJykabf5VILcIN5fuLa0rY3hkBBgfiZV6xmBNRr3CFnVm5c_CnuofMFy94A6AQZFQ42IlcYCcwoj1GIkfi3si3L9PvVndFz0fgTq4h-A" \
    -H "Cache-Control: no-cache" \
    -H "Content-Type: application/json" \
    --url "https://appinspect.splunk.com/v1/app/report/2cae2712-f5e5-495d-9f6b-739c8505ef65"